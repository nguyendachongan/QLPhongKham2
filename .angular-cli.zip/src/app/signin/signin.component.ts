import { Component ,OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { User } from './user';
import { AccountsService } from '../home/shared/services/accounts.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls:
    [
      '../../../node_modules/bootstrap/dist/css/bootstrap.css',
      '../../../node_modules/font-awesome/css/font-awesome.css',
      './signin.component.css'
    ]
})
export class SigninComponent implements OnInit  {
  user = new User('', '');
  errorMessage = false;
  public account;
 
  constructor(private router: Router,private _accountsService: AccountsService) { }
  ngOnInit() {
    this.account = {'EmployeeId': null, 'UserName': null, 'Password': null} ;
  }
 

  onSubmit(isValid: boolean) {
    if (isValid) {
      console.log(this.account);
      this.router.navigate(['/dashboard']);
    } else {
      this.errorMessage = true;
    }
  }
}
