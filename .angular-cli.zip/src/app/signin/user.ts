export class User {
    constructor(
       public userName: string,
       public passWord: string
    ) {}
}
