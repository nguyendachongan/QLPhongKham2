import { NgModule, CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { NgIf } from '@angular/common';
import { ModalModule } from 'ngx-bootstrap/modal';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';

import {MenuComponent} from './home/shared/layout/menu/menu.component';
import {HeaderComponent} from './home/shared/layout/header/header.component';
import {FooterComponent} from './home/shared/layout/footer/footer.component';
import {DashboardComponent} from './home/dashboard/dashboard.component';
import {BreadcrumbsComponent} from './home/shared/layout/breadcrumbs/breadcrumbs.component';


import { AppComponent } from './app.component';
import {DrugsComponent} from './home/drugs/drugs.component';
import {PatientsComponent} from './home/patients/patients.component';
import {AccountsComponent} from './home/accounts/accounts.component';
import {PrescriptionsComponent} from './home/prescriptions/prescriptions.component';


import {DrugsService} from './home/shared/services/drugs.service';
import {PatientsService} from './home/shared/services/patients.service';
import {AccountsService} from './home/shared/services/accounts.service';
import {PrescriptionsService} from './home/shared/services/prescriptions.service';
import {TypeOfDrugsService} from './home/shared/services/type_of_drugs.service';
import { SigninComponent } from './signin/signin.component';
import { HomeComponent } from './home/home.component';


@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    HeaderComponent,
    FooterComponent,
    DashboardComponent,
    BreadcrumbsComponent,
    PatientsComponent,
    DrugsComponent,
    AccountsComponent,
    PrescriptionsComponent,
    SigninComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ModalModule.forRoot(),
    NgbModule.forRoot(),
    FormsModule
  ],
  providers: [PatientsService, DrugsService, AccountsService, PrescriptionsService, TypeOfDrugsService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule { }

