import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {PatientsComponent} from './home/patients/patients.component';
import {DashboardComponent} from './home/dashboard/dashboard.component';
import {DrugsComponent} from './home/drugs/drugs.component';
import {AccountsComponent} from './home/accounts/accounts.component';
import {PrescriptionsComponent} from './home/prescriptions/prescriptions.component';
import { SigninComponent } from './signin/signin.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  { path: '', redirectTo: '/signin', pathMatch: 'full' },
  {
    path: 'patients',
    component: PatientsComponent
  },
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'accounts',
    component: AccountsComponent
  },
  {
    path: 'dashboard',
    component: DashboardComponent
  },
  {
    path: 'drugs',
    component: DrugsComponent
  },
  {
    path: 'prescriptions',
    component: PrescriptionsComponent
  },
  {
    path: 'signin',
    component: SigninComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
